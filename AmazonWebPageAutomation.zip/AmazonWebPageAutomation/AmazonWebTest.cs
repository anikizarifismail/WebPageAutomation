﻿using AmazonWebPageAutomation;
using Xunit;

namespace AmazonAutomation
{
    class AmazonWebTest { 
        static void Main()
        {
            AmazonWebPage amazonWebPage = new AmazonWebPage();
            amazonWebPage.setDollarCurrencyPreference();

            amazonWebPage.search("laptop");

            //Assert for the first item price is more than 100
            Assert.True(amazonWebPage.getFirstItemPrice() > 100.0, "First listed laptop on page is not priced more than $100");

            amazonWebPage.driver.Quit();
        }
    }
}
﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace AmazonWebPageAutomation
{
    class AmazonWebPage
    {
        const String domainName = "https://www.amazon.com/",
            preferenceClassXPath = "//span[@class='icp-nav-flag icp-nav-flag-us icp-nav-flag-lop']//following-sibling::span[@class='nav-icon nav-arrow']",
            currencyDdnId = "icp-currency-dropdown", saveBtnId = "icp-save-button", 
            searchBoxId = "twotabsearchtextbox", searchButtonId = "nav-search-submit-button";
        public IWebDriver driver;

        //Set driver and navigate to Amazon Web page
        public AmazonWebPage() { 
            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(domainName);
        }

        //Set USD currency for webpage
        public void setDollarCurrencyPreference()
        {
            driver.FindElement(By.XPath(preferenceClassXPath)).Click();
            SelectElement ddnCurrency = new SelectElement(driver.FindElement(By.Id(currencyDdnId)));
            ddnCurrency.SelectByText("$ - USD - US Dollar (Default)");

            driver.FindElement(By.Id(saveBtnId)).Click();

            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            wait.Until(condition =>
            {
                try
                {
                    return !driver.FindElement(By.Id(saveBtnId)).Displayed;
                }
                //Ignore exception as expected for button to disappear
                catch (NoSuchElementException)
                {
                    return true;
                }
            });
        }

        //Search on webpage
        public void search(String query)
        {
            driver.FindElement(By.Id(searchBoxId)).SendKeys(query);
            driver.FindElement(By.Id(searchButtonId)).Click();
        }

        //Get first item price
        public float getFirstItemPrice()
        {
            String price = driver.FindElement(By.XPath("(//span[@class='a-price'])[1]//span[@class='a-offscreen']")).GetAttribute("textContent");
            return float.Parse(price.Substring(1));
        }
    }
}
